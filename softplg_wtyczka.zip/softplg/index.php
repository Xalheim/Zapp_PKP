<?php

echo "Hello, I'm test message of soft util plugin :)";

?>
