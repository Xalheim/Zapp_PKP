<?php

namespace GlpiPlugin\Softplg;
use CommonDBTM;
use CommonGLPI;
use Computer;
use Html;
use Log;
use MassiveAction;
use Session;

class Softplg extends CommonDBTM {



}
